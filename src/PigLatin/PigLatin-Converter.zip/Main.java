import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("Welcome to the First and Last Name PigLatin Converter!");
 //   int x = scan.nextInt();
    
//if (x == 1){
  // System.out.println("Please enter your first name:");
  //   String firstNameOnly = scan.nextLine();
  //   firstNameOnly = firstNameOnly.toLowerCase();
  //   // System.out.println(firstNameOnly);
  //   int w = firstNameOnly.length();
  //   // System.out.println(w);
  //   char result = firstNameOnly.charAt(0);
  //   String firstLetter = "" + result;
  //   // System.out.println("First leter = " + firstLetter);
  //   String restOfWord = firstNameOnly.substring(1);
  //   // System.out.println("Rest of firstNameOnly = " + restOfWord);
  //   System.out.println("Final pig latin:" + restOfWord + firstLetter + "ay");
// } else if (x == 2) {
System.out.println("Please enter your first name:");
  String firstName = scan.nextLine();
  System.out.println("Please enter your last name:");
  String lastName = scan.nextLine();
    firstName = firstName.toLowerCase();
    lastName = lastName.toLowerCase();
    // System.out.println(word);
    int y = firstName.length();
    int z = lastName.length();
    // System.out.println(y);
    // System.out.println(z);
    char result1 = firstName.charAt(0);
    char result2 = lastName.charAt(0);
    String firstLetter1 = "" + result1;
    String firstLetter2 = "" + result2;
    // System.out.println("First leter = " + firstLetter);
    String restOfWord1 = firstName.substring(1);
    String restOfWord2 = lastName.substring(1);
    // System.out.println("Rest of word = " + restOfWord);
    System.out.println("Final pig latin:" + restOfWord1 + firstLetter1 + "ay " + restOfWord2 + firstLetter2 + "ay");
    // } else {
    // System.out.println("The number you entered is not valid.");
    // }
  }
}